((typeof global === "object" && global &&
         global["Object"] === Object) ? global : this)["com"]["knoldus"]["weather"]["Weather"]().main();
